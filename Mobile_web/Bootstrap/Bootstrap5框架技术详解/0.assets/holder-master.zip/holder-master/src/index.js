/*
Holder.js - client side image placeholders
(c) 2012-2020 Ivan Malopinsky - https://imsky.co
*/

module.exports = require('./lib');
